package com.viswa.nmp_cerbung_goofy_goober

data class Cerbungs(var cerbungImg: String, var judul: String, var penulis: String, var likes: Int, var createDate: String, var deskripsi: String, var paragraphs: List<CerbungParagraph>)
