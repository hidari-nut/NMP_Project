package com.viswa.nmp_cerbung_goofy_goober

data class CerbungParagraph(var paragraphContent: String, var author: String)
